Rebecca, the purple turtle.
