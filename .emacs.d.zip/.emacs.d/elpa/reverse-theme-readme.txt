Color theme as 'emacs -r' or 'emacs --reverse-video'.
Frames created by `make-frame-command' or 'emacsclient --create-frame'
are not applied reverse color with '-r' or 'reverse-video' option
