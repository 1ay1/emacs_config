A dark color theme available for a number of editors.
