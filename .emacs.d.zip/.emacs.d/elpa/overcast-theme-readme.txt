    A dark but vibrant color theme.

 Overview of features:

    o   Dark, vibrant
