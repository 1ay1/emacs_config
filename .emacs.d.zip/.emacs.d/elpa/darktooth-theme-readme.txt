 From the darkness... it watches

 Since 0.3.0  : Official release integrated with autothemer
 Since 0.2.0  : Built using autothemer
 Since 0.1.60 : includes `darktooth-modeline'
